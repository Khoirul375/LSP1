/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kalkulator;

/**
 *
 * @author lab
 */
public class kalku31 {
    
    
    public static void main (String [] args) {
        kalku3 kalku = new kalku3 () ;
            
        kalku.setVisible(true);
    }
}
