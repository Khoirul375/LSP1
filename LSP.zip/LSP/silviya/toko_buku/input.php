<?php
// Mengambil action di file koneksi.php
include "koneksi.php";

// Ambil Data yang Dikirim dari Form upload
  $judul =$_POST['judul'];
$pengarang =$_POST['pengarang'];
$penerbit =$_POST['penerbit'];
$gambar = $_FILES['gambar']['name'];

// Ambil ukuran files dalam bentuk bytes
$ukuran_file = $_FILES['gambar']['size'];
// Ambil url path folder
$tmp_file = $_FILES['gambar']['tmp_name'];
$tipe_file = $_FILES['gambar'];
// Set path folder tempat menyimpan gambarnya
$path = "images/".$gambar;

// Cek apakah tipe file yang diupload adalah JPG / JPEG / PNG
//if($tipe_file == "images/jpg" | $tipe_file == "images/jpeg" | $tipe_file == "images/png"){

  // Jika tipe file yang diupload JPG / JPEG / PNG, lakukan tindakan :
  // Cek apakah ukuran file yang diupload kurang dari sama dengan 1MB
  if($ukuran_file <= 1000000){
    
    if(move_uploaded_file($tmp_file, $path)){
      
      $query = "INSERT INTO tbl_buku(judul,pengarang,penerbit,gambar) VALUES('".$judul."','".$pengarang."','".$penerbit."','".$gambar."')";
     
      $sql = mysqli_query($mysqli, $query);

      if($sql){
        // Jika Sukses, Lakukan :
        header("location: tampildata.php"); // Redirectke halaman index.php
      }else{
        // Jika Gagal, Lakukan :
        echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
        echo "<br><a href='tampildata.php'>Kembali Ke Form</a>";
      }
    }else{
      // Jika gambar gagal diupload, Lakukan ini
      echo "Maaf, Gambar gagal untuk diupload.";
      echo "<br><a href='tampildata.php'>Kembali Ke Form</a>";
    }
  }else{
    // Jika ukuran file lebih dari 1MB, lakukan :
    echo "Maaf, Ukuran gambar yang diupload tidak boleh lebih dari 1MB";
    echo "<br><a href='tampildata.php'>Kembali Ke Form</a>";
  }
//else{
  // Jika tipe file yang diupload bukan JPG / JPEG / PNG, lakukan :
  echo "Maaf, Tipe gambar yang diupload harus JPG / JPEG / PNG.";
  echo "<br><a href='tampildata.php'>Kembali Ke Form</a>";

?> 