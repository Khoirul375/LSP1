<?php

include "koneksi.php";

// menangkap data dari form inputbarang.php
$kode = $_POST['kd_barang'];
$nama = $_POST['nama_barang'];
$deskripsi = $_POST['deskripsi'];
$stok = $_POST['stok'];
$harga = $_POST['harga'];
$berat = $_POST['berat'];

$namaFile = $_FILES['gambar']['name'];
$tmpFile = $_FILES['gambar']['tmp_name'];
$ekstensiFile = explode('.',$namaFile);
$ekstensiFile = strtolower(end($ekstensiFile));

$gambar = uniqid() . "." . $ekstensiFile;
move_uploaded_file($tmpFile,'gambar/'.$gambar);

$id_kategori = $_POST['id_kategori'];

// cek apakah submit sudah dikirim
if(isset($_POST['submit'])) {
    // $dataku = mysqli_query($koneksi, "INSERT INTO tbl_barang VALUES ('', '$kode', '$nama', '$deskripsi', '$stok', '$harga', '$berat','$gambar','$id_kategori','$nama_kategori')");
    $dataku = mysqli_query($koneksi,"INSERT INTO tbl_barang(kd_barang, nama_barang, deskripsi, stok,harga, berat,id_kategori, gambar) 
        VALUES('$kode','$nama','$deskripsi','$stok','$harga','$berat','$id_kategori', '$gambar')");
    //pindah halaman 
    header("Location: tampildata.php");
}

?>