/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrayshort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author lab
 */
public class Mengurutkan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("\n");
        
   
        ArrayList<String> nama = new ArrayList<>();
        Scanner key = new Scanner(System.in);
        //Membuat/Menambahkan Elemen Array
        for (int i=1; i<11; i++){
        System.out.print("Masukkan Nama ke- "+i+" = ");
        nama.add(key.nextLine());
        }

      
        System.out.println("__________________________________________");
        System.out.println("Nama Yang Belum Urut ");
        System.out.println(nama);
        System.out.println("__________________________________________");
        
        Collections.sort(nama);
   
        System.out.println("Nama Yang Urut A-Z ");
        System.out.println(nama);
        System.out.println("__________________________________________");
        
        Collections.sort(nama, Collections.reverseOrder());
       
        System.out.println("Nama Yang Urut Z-A ");
        System.out.println(nama);
        System.out.println("__________________________________________");
        
    }
    
}
