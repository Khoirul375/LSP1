<?php
include_once ("koneksi.php");

$tampilkanjenis = mysqli_query($koneksiku, 'SELECT * FROM tbl_jnsbarang ORDER BY kd_jns ASC');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampilkan Jenis Barang</title>
</head>
<body>
    <table width='80%' border=1>
        <center><h2>Data Jenis Barang</h2></center>
        <p>
            <a href="inputjenis.php">
                <input type="submit" value="SIMPAN">
            </a>
        </p>
        <tr>
            <th>No</th>
            <th>Kode Jenis</th>
            <th>Nama Jenis</th>
            <th>Action</th>
        </tr>
        <?php
        
        include 'koneksi.php';

        $no = 1;

        while($datajns = mysqli_fetch_array ($tampilkanjenis))
       {
        echo "<tr>";
        echo "<td>".$no++."</td>";
        echo "<td>".$datajns['kd_jns']."</td>";
        echo "<td>".$datajns['nama_jns']."</td>";

        echo "<td><a href='editjenis.php?kd_jns=$datajns[kd_jns]'>
        <button type='click' value='click'>UPDATE</a></button> ||
        <a href='hapusjenis.php?kd_barang=$datajns[kd_jns]'>
        <button type='click' value='click'>DELETE</a></button>
        </td></tr>";
       }
       mysqli_close($koneksiku);
        ?>

    </table>
</body>
</html>