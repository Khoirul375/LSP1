<?php 
include "koneksi.php";



$id = $_POST['id_buku'];
$judul = $_POST['judul'];
$pengarang = $_POST['pengarang'];
$penerbit = $_POST['penerbit'];
$gambarLama = $_POST['gambarLama'];
$create = $_POST['created_at'];
$update = $_POST['updated_at'];



if($_FILES["gambar"]["error"] == 4){

    $gambar = $gambarLama;
} else {

$namaFile = $_FILES['gambar']['name'];
$tmpFile = $_FILES['gambar']['tmp_name'];
$ekstensiFile = explode('.', $namaFile);
$ekstensiFile = strtolower(end($ekstensiFile));

$gambar = uniqid(). "." . $ekstensiFile;
unlink('gambar/' . $gambarLama);
move_uploaded_file($tmpFile, 'gambar/' . $gambar);
}




if(isset($_POST['edit'])) {
    $update = mysqli_query($koneksi, "UPDATE tbl_latihan SET judul='$judul', pengarang='$pengarang', penerbit='$penerbit', gambar='$gambar', created_at='$create', updated_at
    = '$update' WHERE id_buku=$id");
    header("Location: tampil.php");


}

?>