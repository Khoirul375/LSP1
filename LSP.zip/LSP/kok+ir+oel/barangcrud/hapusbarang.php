<?php

include "koneksi.php";

$id = $_GET['id'];
$hapusbarang = mysqli_query($koneksi, "DELETE FROM tbl_barang WHERE id=$id");
header("Location: tampildata.php");

?>