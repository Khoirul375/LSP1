/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class Luas {
    String namaBangun;
    int p;
    int l;
    int L; //variabel
    
    //Constructor
    //_namaBarang=parameter 1/atribut 1, int _harga=parameter 2,dst
    public Luas (String _namaBangun, int _p, int _l){
        namaBangun = _namaBangun;
        p = _p;
        l = _l;
    }
    
    //Method/function untuk jumlah total
    public int L() {
        L = p*l;
        return L;
    }
    
    //Membuat untuk menampilkan data dari atribut dan parameter
    public void tampilData(){
        
        System.out.println("Nama Bangun :" +namaBangun);
        System.out.println("panjang :" +p);
        System.out.println("lebar :" +l);
        System.out.println("-----------------");
        System.out.println("Luas :" +L());
    }
}