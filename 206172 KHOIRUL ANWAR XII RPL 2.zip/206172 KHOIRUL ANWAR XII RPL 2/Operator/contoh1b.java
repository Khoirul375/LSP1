package Operator;

public class contoh1b {
    public static void main (String[]args) {
    int a = 20;
    int b = 10;
    System.out.println("Hasil dari a%b =" +(a%b));
    System.out.println("Hasil dari a*b =" +(a*b));
    System.out.println("Hasil dari a ditambah" +(a++));
    }
}
