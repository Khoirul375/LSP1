/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package democonstructor1;

/**
 *
 * @author LAB
 */
class Kotak {
    double panjang;
    double lebar;
    double tinggi;
    // Mendefinisikan constructor untuk kelas Kotak
    Kotak() {
        panjang = 4;
        lebar = 3;
        tinggi = 2;
    }
    double hitungVolume() {
    return (panjang * lebar * tinggi);
    }
}
class DemoConstructor1 {
    public static void main(String[] args) {
        Kotak k1;
        k1 = new Kotak();
        System.out.println("Volume k1 = " + k1.hitungVolume());
    }
}