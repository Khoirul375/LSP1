<?php
$angka1 = 5;
$angka2 = 3;
$c = $angka1+$angka2;
echo $c;
?>