public class IfSatuPilihan{
    public static void main(String args[]){
        int bil;
        bil=0;
        if (bil==0)
        System.out.println("Bilangan Nol");
    }
}