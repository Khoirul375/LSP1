<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Document</title>
</head>

<body>

    <div class="row">
        <div class="col-sm-12 bg-secondary text-center">
            <h2 class="text-light text-bold mb-3">DAFTAR BUKU</h2>
        </div>
</div>
<br>
<div class="container">
    <div class="clearfix">
        <a class="float-left satu btn btn-primary" href="form.html">Tambah</a>
        <div class ="col">
        <form class="d-flex dua" method="post" action="cari.php" enctype="multipart/form-data" role="search">
                    <input class="form-control" name="judul" type="search" placeholder="Cari Judul Buku.." aria-label="Cari">
                    <button class="btn btn-outline-success" name="submit" type="submit">Cari</button>
                  </form>
</div>
    </div>
    <br>
</div>
<hr>
<div class="container-fluid">

</br>

<?php
include "config.php";

        if(isset($_POST['submit'])){
            $judul = $_POST['judul'];
$cari = mysqli_query($koneksi, "SELECT * FROM tbl_satu WHERE judul= '$judul'");
$col = mysqli_num_rows($cari);

if($col>0){ 
     while ($data = mysqli_fetch_array($cari)){
        ?>
        <div class='card' style='width: 18rem;'>
        <h5 class="card-title ms-3 mt-2"><?php echo $data['judul'];?></h5>
        <img src='images/<?php echo $data['gambar'];?>' class='cardimg'>
         <div class='card-body'>
         <a href="Edit.php?id=<?=$data['id_buku'];?>"class='btn btn-warning mt-3'>Edit</a>
          <a href='hapus.php?id=<?=$data['id_buku'];?>' class='btn btn-danger mt-3'>Hapus</a>
         
        </div>
        </div>
        <?php
        }
       
    
  
}
}

else{
   die("<h2 class='text-center'>DATA TIDAK ADA</h2>
   <h2 class='text-center'> KEMBALI KE <a href='index.php'> HOME </a></h2>");
}

?>
</div>
</body>
</html>

