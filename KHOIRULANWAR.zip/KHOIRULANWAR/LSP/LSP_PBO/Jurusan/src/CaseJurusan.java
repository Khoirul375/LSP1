/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
import java.util.Scanner;
public class CaseJurusan{
        public static void main(String args[]){

            System.out.println("*****                       *****");
            System.out.println("*****Program Pilihan Jurusan*****");
            System.out.println("*****                       *****");
            
            Scanner masuk = new Scanner(System.in);
            int pil;
            System.out.print("Masukkan Pilihan Angka (1-6) : ");
            pil = masuk.nextInt();
            masuk.close();
            switch (pil) {
            case 1:System.out.println("Program Keahlian TITL");
            break;
            case 2:System.out.println("Program Keahlian TEI");
            break;
            case 3:System.out.println("Program Keahlian TAV");
            break;
            case 4:System.out.println("Program Keahlian TBSM");
            break;
            case 5:System.out.println("Program Keahlian TKRO");
            break;
            case 6:System.out.println("Program Keahlian RPL");
            break;
            default:
            System.out.println("Input salah!");
            break;
        }
    }
}
