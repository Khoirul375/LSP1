package LuasBangun;

public class Persegi {
    int s, luas;

    Persegi(int _s) {
        s = _s;
    }

    public int luas() {
        luas = s * s;
        return luas;
    }

    public void tampil() {
        System.out.println("Sisi = " + s);
        System.out.println("Luas = " + luas);
    }
}
