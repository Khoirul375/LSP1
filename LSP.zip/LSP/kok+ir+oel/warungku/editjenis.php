<?php
include_once("koneksi.php");

if(isset($_POST['update'])) {
    $kdjnse=$_POST['kd_jns'];
    $namajnse=$_POST['nama_jns'];


    $editnya=mysqli_query($koneksiku, "UPDATE tbl_barang
    SET nama_barang='$namabarange',harga_beli='$hargabeline',
    harga_jual='$hargajuale',stok_barang='$stokbarange' WHERE kd_barang=$kdbarange");

    header("Location:tampiljenis.php");
}
?>