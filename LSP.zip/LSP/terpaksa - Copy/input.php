<?php 

include "koneksi.php";


?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Buku</title>
</head>
<body>
    <h1>Input Buku</h1>
    <form action="kirim.php" method="post" enctype="multipart/form-data">
        <div> 
            <label for="judul">Judul</label>
            <input type="text" name="judul" id="judul">
        </div>
        <div> 
            <label for="pengarang">Pengarang</label>
            <input type="text" name="pengarang" id="pengarang">
        </div>
        <div> 
            <label for="penerbit">Penerbit</label>
            <input type="text" name="penerbit" id="penerbit">
        </div>
        <div> 
            <label for="gambar">Gambar</label>
            <input type="file" name="gambar" id="gambar">
        </div>
        <div> 
            <button type="submit" name="submit">Kirim Buku</button>
        </div>
    </form>    
  </body>
</html>