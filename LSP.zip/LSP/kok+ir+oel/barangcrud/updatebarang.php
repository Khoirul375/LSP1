<?php

include "koneksi.php";

$id = $_POST['id'];
$kode = $_POST['kd_barang'];
$nama = $_POST['nama_barang'];
$deskripsi = $_POST['deskripsi'];
$stok = $_POST['stok'];
$harga = $_POST['harga'];
$berat = $_POST['berat'];
$gambar = $_POST['gambar'];
$id_kategori = $_POST['id_kategori'];

if(isset($_POST['edit'])) {
    $updatebarang = mysqli_query($koneksi, "UPDATE tbl_barang SET kd_barang='$kode', nama_barang='$nama', deskripsi='$deskripsi', stok='$stok', harga='$harga', berat='$berat', gambar='$gambar',id_kategori='$id_kategori' WHERE id=$id");
    header("Location: tampildata.php");
}


?>