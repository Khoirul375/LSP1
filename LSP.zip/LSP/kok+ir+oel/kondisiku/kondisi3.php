<?php
// tag/syntax pembuka
$nilai = 86;
if ($nilai == 90) {
    echo "Predikat Anda A";
} elseif ($nilai <= 86) {
    echo "Predikat Anda B";
} elseif ($nilai >= 76) {
    echo "Predikat Anda C";
} else {
    echo "Anda Diluar Predikat";
}
?>