<?php 
include "koneksi.php";
$tampildata = mysqli_query($hubungkan,"SELECT * FROM tbl_buku");
?>
<html>
    <head>
        <title>Tampil Buku</title>
    </head>
    <body>
        <table border = 2>
            <tr>
                <th>ID BUKU</th>
                <th>JUDUL BUKU</th>
                <th>PENGARANG</th>
                <th>PENERBIT</th>
                <th>TAHUN TERBIT</th>
                <th>JUMLAH BUKU</th>
                <th>GAMBAR</th>
                <th>AKSI</th>
               
            </tr>
            <?php 
            while ($data = mysqli_fetch_array($tampildata)){

            ?>
                <tr>
                    <td><?php echo $data['id_buku']?></td>
                    <td><?php echo $data['judul_buku']?></td>
                    <td><?php echo $data['pengarang']?></td>
                    <td><?php echo $data['penerbit']?></td>
                    <td><?php echo $data['thn_terbit']?></td>
                    <td><?php echo $data['jml_buku']?></td>
                    <td><img src= "gambar/<?php echo $data['gambar']?>" height ="50" width="50"></td>
                    <td>
                        <a href = "editbuku.php?id=<?php echo $data ['id_buku']?>">edit |
                        <a href = "hapusbuku.php?id=<?php echo $data ['id_buku']?>">Hapus
                    </td>
                </tr>
                <?php }?>
        </table>
    </body>
</html>