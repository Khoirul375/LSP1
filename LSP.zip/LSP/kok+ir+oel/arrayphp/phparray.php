<?php
$kd_barang = [1001,1002,1003,1004];

$nama_barang = [
    "Sarimi",
    "Sabun",
    "Gula",
    "Sikat Gigi",
];

$harga_beli = [4000,3000,15000,8000];
$harga_jual = [5000,4000,16000,9000];

$stok = [10,5,20,5];

echo "<center>";
echo "<h2> Data Barang </h2>";
echo "<hr>";

echo "<table border =1>";
echo "<tr>";
echo "<th> KODE BARANG </th>";
echo "<th> NAMA BARANG </th>";
echo "<th> HARGA BELI </th>";
echo "<th> HARGA JUAL </th>";
echo "<th> STOK BARANG </th>";
echo "</tr>";

echo "<tr>";
// Membuat Suatu Perulangan Untuk Menampilkan Data Array
for ($i = 0; $i<=3; $i++) {
    echo "<tr>";
    echo "<td>".$kd_barang[$i]."</td>";
    echo "<td>".$nama_barang[$i]."</td>";
    echo "<td>".$harga_beli[$i]."</td>";
    echo "<td>".$harga_jual[$i]."</td>";
    echo "<td>".$stok[$i]."</td>";
    echo "</tr>";
}
echo "</tr>";
echo "</table>";
?>