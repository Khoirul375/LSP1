<?php 

include "koneksi.php";

$id = $_GET['id_buku'];

$ambilbarang = mysqli_query($koneksi, "SELECT * FROM tbl_latihan WHERE id_buku=$id");

while($data = mysqli_fetch_assoc($ambilbarang)){
$judul = $data['judul'];
$pengarang = $data['pengarang'];
$penerbit = $data['penerbit'];
$gambar = $data['gambar'];

}
// if (isset($_GET['id_buku'])) {
//     $id = $_GET['id_buku'];
//     $ambilbarang = "SELECT * FROM tbl_latihan where id_buku = '$id'";
//     // $result_pendaftar = mysqli_query($koneksi, $ambilbarang);
//     // $data_pendaftar = mysqli_fetch_array($result_pendaftar);
//     // $judul = $data['judul'];
//     // $pengarang = $data['pengarang'];
//     // $penerbit = $data['penerbit'];
//     // $gambar = $data['gambar'];
//    }else{
//     echo 'data kosong';
//    }
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
</head>
<body>
    <h1>Edit Buku</h1>
    <form action="update.php" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id_buku" value="<?php echo $id ?>">
    <input type="hidden" name="gambarLama" value="<?php echo $gambar ?>">
        <div> 
            <label for="judul">Judul</label>
            <input type="text" name="judul" id="judul" value="<?php echo $judul?>">
        </div>
        <div> 
            <label for="pengarang">Pengarang</label>
            <input type="text" name="pengarang" id="pengarang" value="<?php echo $pengarang?>">
        </div>
        <div> 
            <label for="penerbit">Penerbit</label>
            <input type="text" name="penerbit" id="penerbit" value="<?php echo $penerbit?>">
        </div>
        <div> 
            <img src="gambar/<?php echo $gambar?>" width="50">
            <label for="gambar">gambar</label>
            <input type="file" name="gambar" id="gambar">
        </div>
        <div> 
            <button type="submit" name="edit">Edit Buku</button>
        </div>
    </form>    
  </body>
</html>