/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class LaptopMain {
    public static void main (String[] args) {
        Laptop lap1 = new Laptop();
        
        lap1.pemilik = "ILHAM GOD";
        lap1.merk = "LENOPOP";
        lap1.ukuranLayar = 14.00;
        lap1.hidupkanLaptop();
        lap1.matikanLaptop();
        
        //Menampilkan objek ke monitor
        System.out.println("Pemilik Laptop "+lap1.pemilik);
        System.out.println("Merk Laptopnya "+lap1.merk);
        System.out.println("Ukuran Layar "+lap1.ukuranLayar);
        System.out.println(lap1.hidupkanLaptop());
        System.out.println(lap1.matikanLaptop());
    }
    
}
