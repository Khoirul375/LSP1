<?php

$nama = "Jago Kandang";
echo $nama;

?>