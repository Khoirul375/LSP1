<?php

// koneksi ke database
// mysqli_connect(hostname, username, pw, nama db)
$koneksi = mysqli_connect("localhost", "root","", "db_barang_aseli");

if(!$koneksi){
    //jika koneksi gagal
    die("gagal terhubung");
}

//multi line = alt + shif + a
/*else {
    //jika koneksi berhasil
    echo "berhasil terhubung";
}*/


?>