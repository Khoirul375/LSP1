// public class Latihan2 {
//     /**
//      * @param args
//      */
//     public static void main(String[] args){
//         int bil1=10;
//         int bil2=20;
//         int bil3=bil1+bil2;

//         System.out.println("Angka dari variable bil1 = "+bil3);
//     }
// }
public class Latihan2 {
    public static void main(String[] args){
    // void karena tidak ada fungsi yang membalikkan nilai
    // main karena hanya satu file
        int bilangan1,bilangan2;
        int tambah,kurang,kali,bagi,sisa_bagi;
    //int = tipe data, bilangan1&2 = nama variabel 
        bilangan1=30;
        bilangan2=20;
        tambah=bilangan1+bilangan2;
        kurang=bilangan1-bilangan2;
        kali=bilangan1*bilangan2;
        bagi=bilangan1/bilangan2;
        sisa_bagi=bilangan1%bilangan2;

    //Output
        System.out.println("===========================");
        System.out.println("Angka dari variabel bil1 = "+bilangan1);
        System.out.println("Angka dari variabel bil2 = "+bilangan2);
        System.out.println("===========================");
        System.out.println("Penjumlahan bil1 dan bil2 = "+tambah);
        System.out.println("Pengurangan bil1 dan bil2 = "+kurang);
        System.out.println("Perkalian bil1 dan bil2 = "+kali);
        System.out.println("Pembagian bil1 dan bil2 = "+bagi);
        System.out.println("Sisa Bagi bil1 dan bil2 = "+sisa_bagi);
        System.out.println("===========================");
    }
}