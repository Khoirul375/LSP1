/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class PenjualanMain {
    public static void main (String[] args){
        //Membuat Objek
        Penjualan brg1 = new Penjualan("Sabun", 500, 10);
        brg1.tampilData();
        System.out.println("-----------------");
        System.out.println("Program Penjualan");
        System.out.println("-----------------");
    }
}
