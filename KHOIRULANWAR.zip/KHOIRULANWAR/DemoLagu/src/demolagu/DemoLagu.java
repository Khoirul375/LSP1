/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demolagu;

/**
 *
 * @author LAB
 */
class Lagu { 
    private String band; 
    private String judul; 
    public void IsiParam(String judul,String band) { 
        this.judul = judul; 
        this.band = band; 
    } 
    public void cetakKeLayar() { 
        if(judul==null && band==null) return; 
        System.out.println("Judul : " + judul +"\nBand : " + band); 
    } 
} 
public class DemoLagu { 
    public static void main(String[] args) { 
        Lagu song = new Lagu(); 
        song.IsiParam("Dance Beside","All American Reject "); 
        song.cetakKeLayar(); 
    } 
}