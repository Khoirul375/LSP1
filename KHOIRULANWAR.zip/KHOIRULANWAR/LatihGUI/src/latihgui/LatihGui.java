/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihgui;

/**
 *
 * @author LAB
 */
public class LatihGui {
    public static void main(String[] args) {
        // TODO code application logic here
        KalkulatorSederhana kalku = new KalkulatorSederhana();
        kalku.setVisible(true);
    }
}
