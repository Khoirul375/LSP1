<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet"
    href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script
    src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script
    src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script
    src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="assets/costom.css">
</head>
<body>
    <div class="row">
        <div class="col-sm-12 bg-primary text-center">
            <h2 class="text-light">Kelola Data Barang</h2>
        </div>
    </div>
<br><br>
<div class="container">
    <div class="row">
        <div class="col-sm-6 offset-sm-3">
            <h5 class="font-weight-bold">Input Data Barang</h5>
            <br>
            <form action="inputbarang.php" method="post" name="inputbarang">
                <div class="form-group row">
                    <label class="col-sm-3 col-form-label">KODE BARANG</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control rounded-pill" name="kdbarang">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-3 col-form-label">NAMA BARANG</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control rounded-pill" name="nmbarang">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-3 col-form-label">HARGA BELI</label>
                    <div class="col-sm-9">
                        <textarea type="text" class="form-control" name="hargabeli" id=
                        "deskripsi"></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-3 col-form-label">HARGA JUAL</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control rounded-pill" name="hargajual">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-3 col-form-label">STOK BARANG</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control rounded-pill" name=
                        "stokbarang">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-3 col-form-label">BERAT</label>
                    <div class="col-sm-5">
                        <input type="text" class="form-control rounded-pill" name=
                        "berat">
                    </div>
                </div>
                <div class="col-sm-3 offset-sm-4">
                    <button type="simpan" class="btn btn-success" name="simpan" value="simpan"> Tambah</button>
                    <div class="pt-2">
                    <a href="index.php">
                        <button type="button" class="btn btn-primary" value="batal">Batal</button>
                    </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
<?php
if(isset($_POST['simpan'])) {
    $kdbarange = $_POST ['kdbarang'];
    $namabarange = $_POST ['nmbarang'];
    $belibarange = $_POST ['hargabeli'];
    $jualbarange = $_POST ['hargajual'];
    $stokbarange = $_POST ['stokbarang'];
    $berate = $_POST ['berat'];

    include_once("koneksi.php");

    $inputdata = mysqli_query($koneksiku,
    "INSERT INTO tbl_barang(kd_barang,nama_barang,harga_beli,harga_jual,stok_barang,berat)
    VALUES ('$kdbarange','$namabarange','$belibarange','$jualbarange','$stokbarange','$berate')");

    echo "Data Barang Berhasil Disimpan";
    header("Location:index.php");
}
?>