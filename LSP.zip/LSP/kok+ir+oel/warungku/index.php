<?php
    $no = 1;
    include 'koneksi.php';
    $tampilkandata = mysqli_query($koneksiku,"SELECT * FROM tbl_barang ORDER BY kd_barang DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Barang</title>
    <link rel="stylesheet"
    href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/costom.css">
    <script
    src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script
    src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script
    src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="row">
        <div class="col-sm-12 bg-primary text-center">
            <h2 class="text-light">Kelola Data Barang</h2>
        </div>
    </div>
<br><br>
<div class="container">
    <div class="clearfix">
        <h4 class="float-left font-weight-bold">Data Barang</h4>
        <a class="float-right btn btn-primary" href="inputbarang.php">Tambah Data</a>
    </div>
    <br>
    <table class="table table-bordered">
        <thead>
            <tr align="center">
            <th>NO</th>
            <th>KODE BARANG</th>
            <th>NAMA BARANG</th>
            <th>HARGA BELI</th>
            <th>HARGA JUAL</th>
            <th>STOK BARANG</th>
            <th>BERAT</th>
            <th>AKSI</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while ($datane = mysqli_fetch_array($tampilkandata)) {
                    echo "<tr>";
                    echo "<td>".$no++."</td>";
                    echo "<td>".$datane['kd_barang']."</td>";
                    echo "<td>".$datane['nama_barang']."</td>";
                    echo "<td>".$datane['harga_beli']."</td>";
                    echo "<td>".$datane['harga_jual']."</td>";
                    echo "<td>".$datane['stok_barang']."</td>";
                    echo "<td>".$datane['berat']."</td>";

                    echo "<td><a href='editbarang.php?kd_barang=$datane[kd_barang]'>
                    <button type='click' value='click'>Edit</a></button> ||
                    <a href='hapusbarang.php?kd_barang=$datane[kd_barang]'>
                    <button type='click' value='click'>Delete</a></button>
                    </td></tr>";
                    }
                mysqli_close($koneksiku);
            ?>
        </tbody>
    </table>
    </div>
</body>
</html>