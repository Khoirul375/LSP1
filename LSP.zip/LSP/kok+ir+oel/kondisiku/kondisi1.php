<?php
// tag/syntax pembuka
$cuaca ="cerah";
if ($cuaca =="cerah"){
    echo "Saya Pergi";
}
?>