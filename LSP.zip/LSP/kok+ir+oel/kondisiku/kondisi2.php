<?php
// tag/syntax pembuka
$cuaca ="cerah";
if ($cuaca =="hujan"){
    echo "Saya Pergi";
}
else {
    echo "Saya Coli";
}
?>