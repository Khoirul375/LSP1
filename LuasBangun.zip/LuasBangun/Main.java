package LuasBangun;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        Menu menu = new Menu();
        menu.tampil();

        switch (menu.pil) {
            case 1:
                int panjang, lebar;
                System.out.print("Masukkan Panjang : ");
                panjang = keyboard.nextInt();
                System.out.print("Masukkan Lebar : ");
                lebar = keyboard.nextInt();
                PersegiPanjang pp = new PersegiPanjang(panjang, lebar);
                pp.luas();
                pp.tampil();
                menu.tanya();
                break;
        
            case 2:
                int r;
                System.out.print("Masukkan Jari - jari : ");
                r = keyboard.nextInt();
                Lingkaran lingkaran = new Lingkaran(r);
                lingkaran.luas();
                lingkaran.tampil();
                menu.tanya();
                break;
        
            case 3:
                int s;
                System.out.print("Masukkan Sisi : ");
                s = keyboard.nextInt();
                Persegi persegi = new Persegi(s);
                persegi.luas();
                persegi.tampil();
                menu.tanya();
                break;
        
            default:
            System.out.println("Pilihan tidak tersedia");
                break;
        }

    }
}