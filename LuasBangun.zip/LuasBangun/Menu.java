package LuasBangun;

import java.util.Scanner;

public class Menu {
    int pil;
    String answer;

    public void tanya() {
        Scanner keyboard = new Scanner(System.in);

        System.out.print("Ingin menghitung luas lagi? (y/n) : ");
        answer = keyboard.nextLine();
        switch (answer) {
            case "y":
                tampil();
                break;
        
            default:
                break;
        }
    }

    public void tampil() {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("* Program Menghitung Luas Bangun *");
        System.out.println("** MENU UTAMA **");
        System.out.println("1. Hitung Luas Persegi Panjang");
        System.out.println("2. Hitung Luas Lingkaran");
        System.out.println("3. Hitung Luas Persegi");
        System.out.print("Pilihlah (1-3) : ");
        pil = keyboard.nextInt();
    }
}
