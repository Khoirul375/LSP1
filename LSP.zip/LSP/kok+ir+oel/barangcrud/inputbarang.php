<?php
include "koneksi.php";
$ambilKategori = mysqli_query($koneksi, "SELECT * FROM tbl_kategori"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Barang</title>
    <link rel="styleheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.main.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
<div class="row">
        <div class="col-sm-12 bg-primary text-center">
            <h2 class="text-alight text-white">Kelola Data Barang</h2>
        </div>
    </div>
    <br></br>
<div class="container">
<div class="row">
<div class="col-sm-6 offset-sm-3">    
    <h3>Input Barang</h3>
    <br>   
    <form action="kirimbarang.php" method="post" enctype="multipart/form-data">
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="kd_barang">Kode</label>
            <div class="col-sm-9">
            <input type="text" class="form-control rounded-pill" name="kd_barang" id="kd_barang">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="nama_barang">Nama</label>
            <div class="col-sm-9">
            <input type="text" class="form-control rounded-pill" name="nama_barang" id="nama_barang">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="deskripsi">Deskripsi</label>
            <div class="col-sm-9">
            <input type="text" class="form-control rounded-pill" name="deskripsi" id="deskripsi">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="stok">Stok</label>
            <div class="col-sm-9">
            <input type="number" class="form-control rounded-pill" name="stok" id="stok">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="harga">Harga</label>
            <div class="col-sm-9">
            <input type="number" class="form-control rounded-pill" name="harga" id="harga">
            </div>
        </div>
        <div  class="form-group row">
            <label class="col-sm-3 col-form-label" for="berat">Berat</label>
            <div class="col-sm-9">
            <input type="number" class="form-control rounded-pill" name="berat" id="berat">
            </div>
        </div>
        <div  class="form-group row">
            <label class="col-sm-3 col-form-label" for="gambar">gambar</label>
            <div class="col-sm-9">
            <input type="file" class="form-control rounded-pill" name="gambar" id="gambar">
            </div>
        </div>
        <div  class="form-group row">
            <label class="col-sm-3 col-form-label" for="id_kategori">ID Kategori</label>
            <div class="col-sm-9">
                <select type="text" class="form-select rounded-pill" name="id_kategori" id="id_kategori">
                    <?php while ($datakategori = mysqli_fetch_assoc($ambilKategori)) { ?>
                        <option value="<?php echo $datakategori['id_kategori']?>">
                        <?php echo $datakategori['kode_kategori']?></option><?php } ?>
                </select>
            </div>
        </div>
        <div >
            <button type="submit" class="btn btn-success" name="submit"> Tambah Barang </button>
        </div>    
    </form>
    </div>
    </div>
    </div>
   
</body>
</html>