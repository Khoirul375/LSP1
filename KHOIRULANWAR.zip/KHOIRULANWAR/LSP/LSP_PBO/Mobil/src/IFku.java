/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class IFku {
    public static void main (String[] args) {
        int NilaiA = 75;
        if (NilaiA > 90)
        {
            System.out.println("Selamat Lulus");
            System.out.println("Sangat Baik");
        }
        else if
            (NilaiA<80){
            System.out.println("Lulus");
            System.out.println("Baik");
        }
        else
        {
            System.out.println("................");
        }
    }
}
