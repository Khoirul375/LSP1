package projectnondragdrop;
/**
 * @author Yudwi Antoro Wibowo
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class NonDragDrop extends Frame{
    private static JButton btnSimpan = new JButton("Simpan"), btnBatal = new JButton("Batal");
    
    public static void main(String[] args){
        
        //pembuatan object frame
        NonDragDrop f  = new NonDragDrop();
        f.setLayout(null);
        f.setSize(400, 600);  
        f.setTitle("AWT dengan Null Layout");
        
        //pembuatan object
        Label lblJudul   = new Label("INPUT DATA SISWA");
        Label lblNama    = new Label("Nama Siswa");
        Label lblGender  = new Label("Jenis Kelamin");
        Label lblKelas   = new Label("Kelas");
        Label lblHobby   = new Label("Hobby");        
        TextField txtNama    = new TextField("");
        CheckboxGroup rd     = new CheckboxGroup();
        Checkbox rdLaki      = new Checkbox("Laki-Laki", rd, true);
        Checkbox rdPerempuan = new Checkbox("Perempuan", rd, false);
        Choice cb            = new Choice();     
        Checkbox cbOlahraga  = new Checkbox("Olah Raga", false);
        Checkbox cbMenyanyi  = new Checkbox("Menyanyi", false);
        Checkbox cbMenari    = new Checkbox("Menari", false); 
        
        Panel pnlLabel = new Panel();        
        Panel pnlKiri  = new Panel();
        Panel pnlKanan = new Panel();
        //-- label
        Label lblPanelNama   = new Label("Nama Siswa");
        Label lblPanelGender = new Label("Jenis Kelamin");
        Label lblPanelKelas  = new Label("Kelas");
        Label lblPanelHobby  = new Label("Hobby");
        //--- output label         
        Label lblPanelNamaOut   = new Label("Nama Siswa");
        Label lblPanelGenderOut = new Label("Jenis Kelamin");
        Label lblPanelKelasOut  = new Label("Religi");
        Label lblPanelHobbyOut  = new Label("Hobby");
        
        //pengaturan posisi
        lblJudul.setBounds(100, 30, 200, 20);
        lblNama.setBounds(20, 60, 100, 20);
        lblGender.setBounds(20, 100, 100, 20);
        lblKelas.setBounds(20, 140, 100, 20);
        lblHobby.setBounds(20, 180, 100, 20);
        rdPerempuan.setBounds(200, 100, 80, 22);
        txtNama.setBounds(120, 60, 200, 22);
        rdLaki.setBounds(120, 100, 80, 22);
        cb.setBounds(120, 140, 100, 100);  
        cbOlahraga.setBounds(120, 180, 80, 22);
        cbMenyanyi.setBounds(220, 180, 80, 22);
        cbMenari.setBounds(300, 180, 80, 22);
        btnSimpan.setBounds(100, 220, 80, 22);
        btnBatal.setBounds(180, 220, 80, 22);
        pnlLabel.setBounds(20, 250, 350, 200);
        //-- panel output
        pnlLabel.setBackground(Color.yellow); 
        pnlKiri.setBackground(Color.blue);
        pnlKanan.setBackground(Color.green);
        /*
        lblPanelNama.setBounds(20, 60, 100, 20);
        lblPanelGender.setBounds(20, 100, 100, 20);
        lblPanelKelas.setBounds(20, 140, 100, 20);
        lblPanelHobby.setBounds(20, 180, 100, 20);  
        lblPanelNamaOut.setBounds(100, 60, 100, 20);
        lblPanelGenderOut.setBounds(100, 100, 100, 20);
        lblPanelKelasOut.setBounds(100, 140, 100, 20);
        lblPanelHobbyOut.setBounds(100, 180, 100, 20);
        */
        
        //menambahkan object di frame
        f.add(lblJudul);
        f.add(lblNama);
        f.add(lblGender);
        f.add(lblKelas);
        f.add(lblHobby);
        
        f.add(txtNama);
        f.add(rdLaki);      
        f.add(rdPerempuan);      
        
        cb.add("X");
        cb.add("XI");
        cb.add("XII");
        f.add(cb);
               
        f.add(cbOlahraga);
        f.add(cbMenyanyi);
        f.add(cbMenari);
        
        f.add(btnSimpan);
        f.add(btnBatal);
        
        //Papan panel
        f.add(pnlLabel);
        pnlLabel.add(pnlKiri, BorderLayout.WEST);
        pnlLabel.add(pnlKanan, BorderLayout.EAST);
        
        //pnlLabel.add(new Button("Simpan"), BorderLayout.WEST);
        //pnlLabel.add(new Button("Batal"), BorderLayout.EAST);
        
        pnlKiri.add(lblPanelNama);
        pnlKiri.add(lblPanelGender);
        pnlKiri.add(lblPanelKelas);
        pnlKiri.add(lblPanelHobby);        
        
        pnlKanan.add(lblPanelNamaOut);
        pnlKanan.add(lblPanelGenderOut);
        pnlKanan.add(lblPanelKelasOut);
        pnlKanan.add(lblPanelHobbyOut);
          
        //menampilkan frame
        f.setVisible(true);
        /*
        BTNclear.addActionListener(new ActionListener(){
        publicvoid actionPerformed (ActionEvent evn){
        BTNsimpan.setVisible(false);
        BTNclear.setVisible(false);
        LBLclear.setVisible(true);
        Panel1.add(LBLclear);
        BTNsimpan.setEnabled(false);
        }
        });
                */
        btnSimpan.addActionListener(new ActionListener(){
            public void actionPerformed (ActionEvent evn){
                lblPanelNamaOut.setText(txtNama.getText());
                lblPanelGenderOut.setText(rd.getSelectedCheckbox().getLabel());
                lblPanelKelasOut.setText(cb.getSelectedItem());
                //lblPanelHobbyOut.setText(cb.SelectedItem());
            }
        });
    }
}
