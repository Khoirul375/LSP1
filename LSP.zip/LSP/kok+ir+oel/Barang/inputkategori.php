<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script
src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script
src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script
src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="assets/costom.css">
</head>
<body>
    <div class="row">
        <div class="col-sm-12 bg-primary text-center">
            <h2 class="text-light">Kelola Data Barang</h2>
</div>
</div>
<br><br>
<div class="container">
<div class="row">
<div class="col-sm-6 offset-sm-3">
<h5 class="font-weight-bold">Input Data kategori</h5>
<br>
<form action="" method="post" enctype="multipart/form-data">
<div class="form-group row">
<label class="col-sm-3 col-form-label">Kode</label>
<div class="col-sm-8">
<input type="text" class="form-control rounded-pill" name="kode">
</div>
</div>
<div class="form-group row">
<label class="col-sm-3 col-form-label">Nama</label>
<div class="col-sm-9">
<input type="text" class="form-control rounded-pill" name="nama">
</div>
</div>
<div class="col-sm-3 offset-sm-4">
<button type="submit" class="btn btn-success" name="submit"> Tambah
 </button>
</div>
</form>
</div>
</div>
</div>
</body>
</html>
<?php
include 'config.php';
if (isset($_POST['submit'])) {
$kode = $_POST['kode'];
$nama = $_POST['nama'];

$query = "INSERT INTO tbl_kategori(kode_kategori, nama_kategori) VALUES('".$kode."','".$nama."')";
$sql = mysqli_query($mysqli, $query);
 }

?>