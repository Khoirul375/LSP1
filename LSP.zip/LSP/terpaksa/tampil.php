<?php 

include "koneksi.php";
$ambildata = mysqli_query($koneksi, "SELECT * from tbl_latihan");


?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tampil data</title>
</head>
<body>
    <h1>Data Barang</h1>
    <a href="input.php">tambah </a>
    <table border="1">
        <thead>
          <tr>
          <th>ID</th>
            <th>KODE</th>
            <th>NAMA</th>
            <th>GAMBAR</th>
            <th>ACTION</th>
          </tr>
        </thead>
        <tbody>
            <?php while($data = mysqli_fetch_array($ambildata)) { ?>
            <tr>
                <td><?php echo $data ['id'] ?></td>
                <td><?php echo $data ['kode'] ?></td>
                <td><?php echo $data ['nama'] ?></td>
                <td> <img src="gambar/<?php echo $data['gambar']?>" width="50"></td>
                <td> <a href="edit.php?id=<?php echo $data ['id'] ?>">Edit</a>
                     <a href="delete.php?id=<?php echo $data ['id'] ?>">Hapus</a>
                </td>
            </tr>



        <?php } ?>
        <tbody>
    </table>
    
  </body>
</html>