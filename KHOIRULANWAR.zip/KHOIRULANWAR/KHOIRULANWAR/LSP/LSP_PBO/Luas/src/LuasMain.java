/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class LuasMain {
    public static void main (String[] args){
        //Membuat Objek
        Luas luas1 = new Luas("Persegi", 60, 10);
        luas1.tampilData();
        System.out.println("-----------------");

//        Luas luas2 = new Luas("Samphoo", 500, 10);
//        luas2.tampilData();
//        System.out.println("-----------------");
//        System.out.println("Program Penjualan");
//        System.out.println("-----------------");
    }
}