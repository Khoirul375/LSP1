package Perulangan;
public class UlangFor {
    public static void main (String args[]){
        int bil;
        for (bil=1;bil<=5;bil++)
        System.out.println(bil);
    }
}