/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class Laptop {
    String merk;
    String pemilik;
    Double ukuranLayar;
    
    //Membuat method/function 1
    String hidupkanLaptop() {
        return "Hidupkan Laptop";
    }
    //Membuat method/function 2
    String matikanLaptop() {
        return "Matikan Laptop";
    }
}
