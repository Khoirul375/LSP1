<?php
    $mysqli = mysqli_connect("localhost","root","","silviya_db");

?>