<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Data Gambar</title>
</head>
<body>
<div class="container-">
<div class="row">
                <div class="col-sm-12 text-center bg-primary headerr">
                     <h2 class="text-light">DAFTAR BUKU</h2>
                 </div>
    
             <div class="row header">
                  <div class="col">
                         <a class="btn bg-primary mt-5 ml-5 text-light" href="form.html" >Tambah</a>
             </div>
            <div class="col">
                <form class="d-flex mt-5" role="search">
                    <input class="form-control" type="search" placeholder="Cari Judul Buku.." aria-label="Cari">
                    <button class="btn btn-outline-success" type="submit">Cari</button>
                  </form><br>
             </div><hr>
</div>
</div>
<div class='container-fluid'>

</br>
<!-- <table> -->
<!-- <tr> -->
  <!-- <th>Gambar</th>
  <th>Nama File</th> -->
 
<!-- </tr> -->

    <!-- Membuat proses tampil data -->

<?php
// Mengambil action dari file koneksi.php
include "koneksi.php";
// Memanggil semua data dalam tabel gambar
$query = mysqli_query ($mysqli, "SELECT * FROM tbl_buku");
// Eksekusili_qry($myqli, $qury);
// Ambil jumlah data dari hasil eksekusi $sql
$col = mysqli_num_fields($query);
// Kondisi peulangan Jika jumlah data lebih dari 0 (Berarti jika data ada)
if($col >0){
    // Mengambil semua data dari hasil eksekusi $sql
  while($data = mysqli_fetch_array($query)){
    ?>
<!-- echo "<td>"; -->

<div class='card' style='width: 18rem;'>
<h5 class="card-title ms-3 mt-2"><?php echo $data['judul']?></h5>
<img src='images/<?php echo $data['gambar'];?>' class='cardimg'>
 <div class='card-body'>
 <a href="edit.php?id=<?=$data['id_buku'];?>"class='btn btn-warning mt-3'>Edit</a>
  <a href='hapus.php?id=<?=$data['id_buku'];?>' class='btn btn-danger mt-3'>Hapus</a>
 
</div>
</div>
<?php
  }
}
  ?>
    <!-- // Jika data tidak ada
 }
// else{
//   echo "<tr><td colspan='5'>Belum ada data gambar</td></tr>";
 }
?> -->


<!-- </table> -->
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>

 