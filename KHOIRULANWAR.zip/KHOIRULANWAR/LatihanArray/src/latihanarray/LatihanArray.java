/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package latihanarray;

/**
 *
 * @author LAB
 */
public class LatihanArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a[]= new int[5];
        a[0]=612;
        a[1]=712;
        a[2]=70;
        a[3]=40;
        a[4]=50;
        
        for(int i=0; i<a.length; i++)
        System.out.println(a[i]);
    }
    
}
