public class contoh1a {
    public static void main (String[]args){
    int x, y, c;
    x=4&6;
    y=5>>>2;
    c=(2+4)*6;
    System.out.println(y);
    System.out.println(c);
    System.out.println(x);

    }
}