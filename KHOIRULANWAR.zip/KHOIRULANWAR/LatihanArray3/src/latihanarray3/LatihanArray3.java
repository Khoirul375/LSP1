/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package latihanarray3;

import java.util.Scanner;

/**
 *
 * @author LAB
 */
public class LatihanArray3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner masuk=new Scanner(System.in);
        String data[]=new String[5];
        int nilai[]=new int[5];
        System.out.println("Masukkan 5 data Siswa");
        for(int i=0;i<5;i++)
        {
        System.out.print("Data ke "+(i+1)+": ");
        data[i]=masuk.nextLine();
        }
        for(int j=0;j<5;j++)
        {
            System.out.print("Nilai ke "+(j+1)+": ");
            nilai[j]=masuk.nextInt();
        }
        
//        int nilai[]=new nilai[5];
//        System.out.println("Masukkan 5 data Siswa");
//        for(int i=0;i<5;i++)
//        {
//        System.out.print("Data ke "+(i+1)+": ");
//        nilai[i]=masuk.nextInt();
//        }
        
        System.out.println("data nilai yang dimasukkan");
        for(int i=0;i<5;i++){
            System.out.println(data[i]);{
        for(int j=0;j<5;j++)
            System.out.println(nilai[j]);}
        }
    }
    
}
