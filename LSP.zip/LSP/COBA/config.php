<?php
$koneksi = mysqli_connect('localhost','root','','karepe');
if(!$koneksi){
    echo("Koneksi Gagal :" .mysqli_connect_error());
}
// else{
//     echo "koneksi berhasil";
// }
?>