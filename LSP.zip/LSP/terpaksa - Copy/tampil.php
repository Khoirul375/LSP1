<?php 

include "koneksi.php";
$ambildata = mysqli_query($koneksi, "SELECT * from tbl_latihan");


?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Buku</title>
</head>
<body>
    <h1>Data Buku</h1>
    <a href="input.php">Tambah Buku</a>
    <table border="1">
        <thead>
          <tr>
          <th>ID</th>
            <th>JUDUL</th>
            <th>PENGARANG</th>
            <th>PENERBIT</th>
            <th>GAMBAR</th>
            <th>CREATED AT</th>
            <th>UPDATE AT</th>
            <th>ACTION</th>
          </tr>
        </thead>
        <tbody>
            <?php while($data = mysqli_fetch_array($ambildata)) { ?>
            <tr>
                <td><?php echo $data ['id_buku'] ?></td>
                <td><?php echo $data ['judul'] ?></td>
                <td><?php echo $data ['pengarang'] ?></td>
                <td><?php echo $data ['penerbit'] ?></td>
                <td> <img src="gambar/<?php echo $data['gambar']?>" width="50"></td>
                <td><?php echo $data ['created_at'] ?></td>
                <td><?php echo $data ['update_at'] ?></td>
                <td> <a href="edit.php?id=<?php echo $data ['id_buku'] ?>">Edit</a>
                <a href="delete.php?id=<?php echo $data ['id_buku'] ?>">Hapus</a>
                </td>
            </tr>



        <?php } ?>
        <tbody>
    </table>
    
  </body>
</html>