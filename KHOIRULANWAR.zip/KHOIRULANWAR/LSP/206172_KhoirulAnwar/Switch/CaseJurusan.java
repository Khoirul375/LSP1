import java.util.Scanner;
public class CaseJurusan{
    public static void main(String args[]){
        Scanner masuk = new Scanner(System.in);
        int pil;
        System.out.print("Masukkan pilihan :S1 TT ");
        pil = masuk.nextInt();
        masuk.close();
        switch (pil) {
        case 1:System.out.println("S1 TE");
        break;
        case 2:System.out.println("S1 SK");
        break;
        case 3:System.out.println("D3 TT");
        break;
        case 4:System.out.println("D3 IF");
        break;
        case 5:System.out.println("S1 TI");
        break;
        default:
        System.out.println("Input salah!");
        break;
        }
    }
}