/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package latihsort;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author LAB
 */
public class LatihSort {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
//        Membuat ArrayList
        ArrayList <Integer> numberis = new ArrayList<>();
        
//        Membuat/menambahkan elemen array
        numberis.add(4);
        numberis.add(2);
        numberis.add(3);
        System.out.println("Data Array yang masih Acak (belum urut) : " + numberis);
        
//        Membuat dan memanggil method class dan objek sort(A-Z)
        Collections.sort(numberis);
        System.out.println("Data Array yang sudah diurutkan(A-Z) : " + numberis);
        
//        Membuat dan memanggil method class dan objek sort(Z-A)
        Collections.sort(numberis, Collections.reverseOrder());
        System.out.println("Data Array yang sudah diurutkan(Z-A) : " + numberis);
    }
    
}