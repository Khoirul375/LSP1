<?php

include 'config.php';
$id= $_GET['id'];
$query = mysqli_query($koneksi,"SELECT * FROM tbl_satu WHERE id_buku='$id'")
or die("Query error : " . mysqli_error($koneksi));
 $data = mysqli_fetch_array($query);



 if(isset($_POST['proses'])){
  $judul = $_POST['judul'];
  $gambar = $_POST['gambar'];
  $pengarang = $_POST['pengarang'];
  $penerbit = $_POST['penerbit'];
 

  $edit = mysqli_query($koneksi, " UPDATE tbl_satu SET 
                                    judul = '$judul',
                                    pengarang = '$pengarang',
                                    penerbit = '$penerbit',
                                    gambar = '$gambar'
                                    WHERE id_buku = '$id'");


if($edit){
  // echo "<script>alert('berhasil')</script>";
  header('Location:index.php');

}
else{
  echo "<script>alert('gagal')</script>";
}
 }



    ?>
            
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Toko Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../toko_buku/css/styletambah.css">
</head>
  <body>
    <div class="container">
        <div class="row">
            <div class="col-md-12 bg-secondary">
                <h5 class="text-light">Tambah Data</h5>
            </div>
            <div class="container container-2">
        <form method="post" class="mt-5">
            <div class="mb-3">
              <label class="form-label">Judul</label>
              <input type="text" class="form-control" name="judul" value="<?php echo $data['judul']; ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Gambar</label>
              <input type='file' class="form-control" name='gambar' accept='image/'  value="<?php echo $data['gambar']; ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Pengarang</label>
              <input type="text" class="form-control" name="pengarang"  value="<?php echo $data['pengarang']; ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Penerbit</label>
              <input type="text" class="form-control" name="penerbit" value="<?php echo $data['penerbit']; ?>">
            </div>
            
            <button type="submit" name="proses" class="btn btn-primary">Submit</button>
          </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
 
   
</body>
</html>

