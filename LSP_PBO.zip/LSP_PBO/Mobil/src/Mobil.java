/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class Mobil {
    String warna ="Biru";
    String merk ="Toyota";
    
    //Membuat Method (Fungsi) dari class objek
    public void maju () {
        System.out.println("Mobil dengan Warna " + warna + " Mereknya " + merk + " Bergerak Maju");
    }
    public void mundur () {
        System.out.println("Mobil dengan Warna " + warna + " Mereknya " + merk + " Bergerak Mundur");
    }
    public void belokKiri () {
        System.out.println("Mobil dengan Warna " + warna + " Mereknya " + merk + " Bergerak Ke Kiri");
    }
    public void belokKanan () {
        System.out.println("Mobil dengan Warna " + warna + " Mereknya " + merk + " Bergerak ke Kanan");
    }
}