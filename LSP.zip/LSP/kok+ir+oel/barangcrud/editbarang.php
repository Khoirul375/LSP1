<?php

include "koneksi.php";

$id = $_GET['id'];

$ambildata = mysqli_query($koneksi, "SELECT * FROM tbl_barang WHERE id=$id");

$ambilKategori = mysqli_query($koneksi, "SELECT * FROM tbl_kategori");

while($data = mysqli_fetch_assoc($ambildata)){
    $kode = $data['kd_barang'];
    $nama = $data['nama_barang'];
    $deskripsi = $data['deskripsi'];
    $stok = $data['stok'];
    $harga = $data['harga'];
    $berat = $data['berat'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="styleheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.main.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
<div class="row">
        <div class="col-sm-12 bg-primary text-center">
    <h1 class="text-white">Edit Barang</h1>
    </div>
    </div>
    <br></br>
<div class="container">
    <form action="updatebarang.php" method="post">
        <input type="hidden" name="id" value="<?php echo $id ?>">
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="kd_barang">Kode</label>
            <div class="col-sm-6">
            <input type="text" class="form-control rounded-pill" name="kd_barang" id="kd_barang" value="<?php echo $kode ?>">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="nama_barang">Nama</label>
            <div class="col-sm-6">
            <input type="text" class="form-control rounded-pill" name="nama_barang" id="nama_barang" value="<?php echo $nama ?>">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="deskripsi">Deskripsi</label>
            <div class="col-sm-6">
            <input type="text" class="form-control rounded-pill" name="deskripsi" id="deskripsi" value="<?php echo $deskripsi ?>">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="stok">Stok</label>
            <div class="col-sm-6">
            <input type="text" class="form-control rounded-pill" name="stok" id="stok" value="<?php echo $stok ?>">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="harga">Harga</label>
            <div class="col-sm-6">
            <input type="text" class="form-control rounded-pill" name="harga" id="harga" value="<?php echo $harga?>">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="berat">Berat</label>
            <div class="col-sm-6">
            <input type="text" class="form-control rounded-pill" name="berat" id="berat" value="<?php echo $berat ?>">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" for="gambar">Gambar</label>
            <div class="col-sm-6">
            <input type="file" class="form-control rounded-pill" name="gambar" id="gambar" value="<?php echo $gambar ?>">
            </div>
        </div>
        <div  class="form-group row">
            <label class="col-sm-3 col-form-label" for="id_kategori">ID Kategori</label>
            <div class="col-sm-9">
                <select type="text" class="form-select rounded-pill" name="id_kategori" id="id_kategori">
                    <?php while ($datakategori = mysqli_fetch_assoc($ambilKategori)) { ?>
                        <option value="<?php echo $datakategori['id_kategori']?>">
                        <?php echo $datakategori['kode_kategori']?></option><?php } ?>
                </select>
            </div>
        </div>
        <div>
            <button type="submit" class="btn btn-success" name="edit"> Edit </button>
        </div>

    </form>
</div>
</body>
</html>
