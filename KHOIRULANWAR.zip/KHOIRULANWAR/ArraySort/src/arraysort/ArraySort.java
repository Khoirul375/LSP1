/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arraysort;

import java.util.*;
/**
 *
 * @author LAB
 */
public class ArraySort {
    
    private String customi;
    
    public ArraySort(String property) {
        this.customi = property;
    }
    
    public String getCustomi() {
        return this.customi;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<ArraySort> listing = new ArrayList();
        listing.add(new ArraySort("Zubaidah"));
        listing.add(new ArraySort("Abidin"));
        listing.add(new ArraySort("Bagus Kusumo"));
        listing.add(new ArraySort("Xampp"));
        listing.add(new ArraySort("Aak"));
        listing.add(new ArraySort("Sodron"));
        listing.add(new ArraySort("Sodron Kulari"));
        listing.add(new ArraySort("Slebewww Bewww"));
        listing.add(new ArraySort("Thomas Slebewww"));
        listing.add(new ArraySort("Ilham Sulapan"));
        listing.add(new ArraySort("What The Hell"));
        
        listing.sort((o1,o2) -> o1.getCustomi().compareTo(o2.getCustomi()));
        
        for(ArraySort obj : listing) {
            System.out.println(obj.getCustomi());
        }
    }    
}