import java.util.Scanner;
public class IfElseIfElse {
    public static void main(String args[]){
        Scanner masuk = new Scanner(System.in);
        int pil;
        System.out.print("Masukkan pilihan : ");
        pil = masuk.nextInt();
        masuk.close();
        if (pil==1)
        System.out.println("Buah Pepaya");
        else if(pil==2)
        System.out.println("Buah Stroberi");
        else if(pil==3)
        System.out.println("Buah Apel");
        else
        System.out.println("Bukan Buah deh");
    }
}
