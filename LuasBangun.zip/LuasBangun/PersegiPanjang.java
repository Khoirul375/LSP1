package LuasBangun;

public class PersegiPanjang {
    int panjang, lebar, luas;

    PersegiPanjang(int _panjang, int _lebar) {
        panjang = _panjang;
        lebar = _lebar;
    }

    public int luas() {
        luas = panjang * lebar;
        return luas;
    }

    public void tampil() {
        System.out.println("Panjang = " + panjang);
        System.out.println("Lebar = " + lebar);
        System.out.println("Luas = " + luas);
    }
}
