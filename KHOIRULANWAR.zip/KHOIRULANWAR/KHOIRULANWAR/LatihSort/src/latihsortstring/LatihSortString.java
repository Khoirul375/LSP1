/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package latihsortstring;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author LAB
 */
public class LatihSortString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
//        Membuat ArrayList
        ArrayList <String> numberis = new ArrayList<>();
        
//        Membuat/menambahkan elemen array
        numberis.add("Usa");
        numberis.add("Asi");
        numberis.add("Isu");
        System.out.println("Data Array yang masih Acak (belum urut) : " + numberis);
        
//        Membuat dan memanggil method class dan objek sort(A-Z)
        Collections.sort(numberis);
        System.out.println("Data Array yang sudah diurutkan(A-Z) : " + numberis);
        
//        Membuat dan memanggil method class dan objek sort(Z-A)
        Collections.sort(numberis, Collections.reverseOrder());
        System.out.println("Data Array yang sudah diurutkan(Z-A) : " + numberis);
    }
    
}