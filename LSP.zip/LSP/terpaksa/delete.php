<?php 


include "koneksi.php";


$id = $_GET['id'];



$ambilbarang = mysqli_query($koneksi, "SELECT * FROM tbl_latihan WHERE id=$id");


while($data = mysqli_fetch_assoc ($ambilbarang)){
    $gambar = $data['gambar'];
}

unlink('gambar/' . $gambar);

$delete = mysqli_query($koneksi, "DELETE FROM tbl_latihan WHERE id=$id");
header("Location: tampil.php");

?>