<?php
include_once("config.php");
$id = $_GET['id'];
$result = "DELETE FROM tbl_barang WHERE id=$id";
$hapus= mysqli_query($mysqli, $result);
if($hapus){
    echo"<script> alert('Data Berhasil Dihapus'); window.location='index.php';</script>";
    
    // echo "<script>Swal.fire({
    //     icon: 'warning',
    //     title: 'Semua Form Harus Diisi'
    //   })
    //     </script>";
}
else{
    echo"<script>alert('Gagal')</script>";
//     header("Location:index.php");
 }

?>