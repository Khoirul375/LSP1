<?php 


include "koneksi.php";


$id = $_GET['id_buku'];



$ambilbarang = mysqli_query($koneksi, "SELECT * FROM tbl_latihan WHERE id_buku=$id");


while($data = mysqli_fetch_assoc ($ambilbarang)){
    $gambar = $data['gambar'];
}

unlink('gambar/' . $gambar);

$delete = mysqli_query($koneksi, "DELETE FROM tbl_latihan WHERE id_buku=$id");
header("Location: tampil.php");

?>