<?php
// Mengambil action di file koneksi.php
include "config.php";

// Ambil Data yang Dikirim dari Form upload
 $judul =$_POST['judul'];
$pengarang =$_POST['pengarang'];
$penerbit =$_POST['penerbit'];
$gambar = $_FILES['gambar']['name'];
$tmp_file = $_FILES['gambar']['tmp_name'];

// Set path folder tempat menyimpan gambarnya
$path = "images/".$gambar;


    if(move_uploaded_file($tmp_file, $path)){
    
      $query = "INSERT INTO tbl_satu(judul,pengarang,penerbit,gambar) VALUES('".$judul."','".$pengarang."','".$penerbit."','".$gambar."')";
      // Eksekusi/ Jalankan query dari variabel $query
      $sql = mysqli_query($koneksi, $query);

        // Cek jika proses simpan ke database sukses atau tidak
      if($sql){
        // Jika Sukses, Lakukan :
        header("location: index.php"); // Redirectke halaman index.php
      }else{
        // Jika Gagal, Lakukan :
        echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
        echo "<br><a href='form.html'>Kembali Ke Form</a>";
      }
    }else{
      // Jika gambar gagal diupload, Lakukan ini
      echo "Maaf, Gambar gagal untuk diupload.";
      echo "<br><a href='form.html'>Kembali Ke Form</a>";
    }

?> 
