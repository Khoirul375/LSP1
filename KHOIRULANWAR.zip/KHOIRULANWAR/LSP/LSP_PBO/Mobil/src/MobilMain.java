/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class MobilMain {
    public static void main (String[] args) {
    //Membuat Objek dari Class Mobil
    Mobil mob1 = new Mobil();
    
    mob1.maju();
    mob1.mundur();
    mob1.belokKiri();
    mob1.belokKanan();
    }
}
