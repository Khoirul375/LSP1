public class FungsiParameter{
    public static int jumlah(int a){
        return a;
        }
        public static void main(String args[]){
        System.out.println("Hasil pemanggilan method jumlah ");
        System.out.println(jumlah(5));
    }
}