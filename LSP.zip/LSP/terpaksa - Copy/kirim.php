<?php 
include "koneksi.php";
$id= $data['id_buku'];
$judul = $_POST['judul'];
$pengarang = $_POST['pengarang'];
$penerbit = $_POST['penerbit'];

$namaFile = $_FILES['gambar']['name'];
$tmpFile = $_FILES['gambar']['tmp_name'];
$ekstensiFile = explode('.', $namaFile);
$ekstensiFile = strtolower(end($ekstensiFile));

$gambar = uniqid(). "." . $ekstensiFile;
move_uploaded_file($tmpFile, 'gambar/' . $gambar);

if(isset($_POST['submit'])) {
    $dataku = mysqli_query($koneksi, "INSERT INTO tbl_latihan VALUES ('', '$judul', '$pengarang', '$penerbit')");
    header("Location: tampil.php");


}

?>