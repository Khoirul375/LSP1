<?php 
include "koneksi.php";



$id = $_POST['id'];
$kode = $_POST['kode'];
$nama = $_POST['nama'];
$gambarLama = $_POST['gambarLama'];



if($_FILES["gambar"]["error"] == 4){

    $gambar = $gambarLama;
} else {

$namaFile = $_FILES['gambar']['name'];
$tmpFile = $_FILES['gambar']['tmp_name'];
$ekstensiFile = explode('.', $namaFile);
$ekstensiFile = strtolower(end($ekstensiFile));

$gambar = uniqid(). "." . $ekstensiFile;
unlink('gambar/' . $gambarLama);
move_uploaded_file($tmpFile, 'gambar/' . $gambar);
}




if(isset($_POST['edit'])) {
    $update = mysqli_query($koneksi, "UPDATE tbl_latihan SET kode='$kode', nama='$nama', gambar='$gambar' WHERE id=$id");
    header("Location: tampil.php");


}

?>