<?php
include 'config.php';
$id = $_GET['id'];
$hapus = mysqli_query($koneksi,"DELETE FROM tbl_satu WHERE id_buku='$id'");
if($hapus){
    echo "<script>alert('BERHASIL DIHAPUS');
    document.location.href = 'index.php';
    </script>";
}
else{
   
    die ("Query gagal dijalankan :".mysqli_error($koneksi));
}
?>