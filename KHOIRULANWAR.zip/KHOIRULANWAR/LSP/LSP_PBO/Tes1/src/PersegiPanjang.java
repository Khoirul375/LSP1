/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class PersegiPanjang {
    int panjang;
    int lebar;
    int luas;
    private static int PersegiPanjang(int panjang, int lebar){
        //Rumus Luas Persegi Panjang = panjang * lebar
        int luas = panjang * lebar;
        return luas;
    }
}
