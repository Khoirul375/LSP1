<?php
// Membuat/mendeklarasikan sebuah nama variabel
// Untuk menangkap data dari form input_barang.html 
$kdbarange = $_POST['kdbarang'];
$namabarange = $_POST['namabarang'];
$hargabarange = $_POST['hargabarang'];
$jmlbarange = $_POST['jmlbarang'];

// Membuat Proses Perhitungan
$total_no_diskon = $hargabarange*$jmlbarange;
$total_diskon = $hargabarange*$jmlbarange;

// Memanggil Nama Variabel
echo "Kode Barang : ".$kdbarange;
echo "<br>";
echo "Nama Barang : ".$namabarange;
echo "<br>";
echo "Harga Barang : ".$hargabarange;
echo "<br>";
echo "Jumlah Barang : ".$jmlbarange;
echo "<br>";

if ($total_diskon >= 100000) {
    $diskon=(($total_diskon*5)/100);
       $total_diskon=($total_diskon-$diskon);
       echo "Total bayar sebelum diskon : ".$total_no_diskon;
       echo "<br>";
       echo "Total bayar setelah diskon 5% : ".$total_diskon;
} else if ($jmlbarange >= 10) {
    $diskon=(($total_diskon*10)/100);
       $total_diskon=($total_diskon-$diskon);
       echo "Total bayar sebelum diskon : ".$total_no_diskon;
       echo "<br>";
       echo "Total bayar setelah diskon 10% : ".$total_diskon;
} else {
    echo "Total bayar : ".$total_no_diskon;
    echo "<br>";
    echo "Antum tidak dapat diskon";
}
?>