<?php 
$hubungkan = mysqli_connect('localhost','root','','pustaka_db');
    if ($hubungkan){
        echo "mysqli_error"($hubungkan);
    }
    else{
        echo"";
    }
?>