<?php
$mysqli = mysqli_connect("localhost","root","","barang");
if(!$mysqli){
    echo "Gagal";
}
?>
