<?php 

include "koneksi.php";

$id = $_GET['id'];

$ambilbarang = mysqli_query($koneksi, "SELECT * FROM tbl_latihan WHERE id=$id");

while($data = mysqli_fetch_assoc($ambilbarang)){
$kode = $data['kode'];
$nama = $data['nama'];
$gambar = $data['gambar'];

}
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Barang</title>
</head>
<body>
    <h1>Input Barang</h1>
    <form action="update.php" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $id ?>">
    <input type="hidden" name="gambarLama" value="<?php echo $gambar ?>">
        <div> 
            <label for="kode">kode</label>
            <input type="text" name="kode" id="kode" value="<?php echo $kode?>">
        </div>
        <div> 
            <label for="nama">nama</label>
            <input type="text" name="nama" id="nama" value="<?php echo $nama?>">
        </div>
        <div> 
            <img src="gambar/<?php echo $gambar?>" width="50">
            <label for="gambar">gambar</label>
            <input type="file" name="gambar" id="gambar">
        </div>
        <div> 
            <button type="submit" name="edit">edit barang</button>
        </div>
    </form>    
  </body>
</html>