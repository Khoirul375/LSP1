<?php //Tag Pembuka

echo "Hallo Teman Saya Belajar PHP";
echo "<hr>"; //Untuk tag membuat baris
print "Assalamualaikum";

// Tag Penutup
?>