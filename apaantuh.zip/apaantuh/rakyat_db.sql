-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2023 at 09:31 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rakyat_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_barang`
--

CREATE TABLE `tbl_barang` (
  `id_barang` int(100) NOT NULL,
  `nama_barang` varchar(250) NOT NULL,
  `jumlah` int(250) NOT NULL,
  `asal_barang` varchar(250) NOT NULL,
  `distributor` varchar(250) NOT NULL,
  `tanggal_masuk` varchar(250) NOT NULL,
  `status_barang` varchar(250) NOT NULL,
  `tahun_pembuatan` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_barang`
--

INSERT INTO `tbl_barang` (`id_barang`, `nama_barang`, `jumlah`, `asal_barang`, `distributor`, `tanggal_masuk`, `status_barang`, `tahun_pembuatan`) VALUES
(1, 'Kambing Hijau', 2, 'Centong', 'Ilham', 'Thu Mar 09 14:26:35 WIB 2023', 'Ready', 2021),
(2, 'Kardus', 5, 'Sumatra', 'Pance Goat', '29 Februari 2024', 'Otw', 2020),
(10011, 'Lawang', 10000, 'Semarang', 'KAI', 'Thu Mar 02 14:50:04 WIB 2023', 'Lawas', 2077);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_buku`
--

CREATE TABLE `tbl_buku` (
  `id_barang` int(10) NOT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `harga_barang` varchar(50) DEFAULT NULL,
  `stok` int(50) DEFAULT NULL,
  `gambar` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_buku`
--

INSERT INTO `tbl_buku` (`id_barang`, `nama_barang`, `harga_barang`, `stok`, `gambar`) VALUES
(1, 'Kelabu Merah Muda', 'Sinar Muda', 0, 'Screenshot (7).png'),
(2, 'Sinarsssuuu', 'Sinar', 0, 'jangan.jpg'),
(3, 'Sinar Matahari', 'Sinar Matahari', 0, 'Buku3.jpg'),
(8, 'Aku si[apa', 'Saya', 0, '058395000_1605759618-shutterstock_1461537431.webp'),
(11, 'Aku Sang Pengarang', 'Saya', 0, 'fem.png'),
(12, 'Siapa Kamu', 'Sang ilahi', 0, 'maketime.jpg'),
(13, 'Bintang', 'Sang ilahi', 0, 'maketime.jpg'),
(14, 'APA COBA', 'Sang ilahi', 0, '1200px-Pac_Man.svg2.png'),
(15, 'Kelabu Merah Muda', 'Sang ilahi', 0, 'tireenemy.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `password`, `level`) VALUES
(1, 'admin', 'admin123', 'admin'),
(2, 'user', 'user123', ''),
(3, 'guest', 'guest123', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_barang`
--
ALTER TABLE `tbl_barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `tbl_buku`
--
ALTER TABLE `tbl_buku`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_barang`
--
ALTER TABLE `tbl_barang`
  MODIFY `id_barang` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10012;

--
-- AUTO_INCREMENT for table `tbl_buku`
--
ALTER TABLE `tbl_buku`
  MODIFY `id_barang` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
