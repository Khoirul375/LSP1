<?php
include 'koneksi.php';
$id = $_GET['id'];
$query = mysqli_query($mysqli, "DELETE FROM tbl_buku WHERE id_buku = $id");

// $hapus = mysqli_query($mysqli, $query);

//if (!$query){
    //echo "<script>
   // alert('Data Berhasil Dihapus.');
    //document.location.href = 'tampildata.php';
    //</script>";
//}
//else{
   
   // die ("Query gagal dijalankan :".mysqli_error($koneksiku));
//}
header("Location:tampildata.php")
?>