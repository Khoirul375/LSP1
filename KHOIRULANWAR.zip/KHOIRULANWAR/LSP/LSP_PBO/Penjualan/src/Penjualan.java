/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class Penjualan {
    String namaBarang;
    int harga;
    int jumlah;
    int total; //variabel
    
    //Constructor
    //_namaBarang=parameter 1/atribut 1, int _harga=parameter 2,dst
    public Penjualan (String _namaBarang, int _harga, int _jumlah){
        namaBarang = _namaBarang;
        harga = _harga;
        jumlah = _jumlah;
    }
    
    //Method/function untuk jumlah total
    public int total() {
        total = harga*jumlah;
        return total;
    }
    
    //Membuat untuk menampilkan data dari atribut dan parameter
    public void tampilData(){
        
        System.out.println("Nama Barang :" +namaBarang);
        System.out.println("Harga Barang :" +harga);
        System.out.println("Jumlah Barang :" +jumlah);
        System.out.println("-----------------");
        System.out.println("Total Harga :" +total());
    }
}
