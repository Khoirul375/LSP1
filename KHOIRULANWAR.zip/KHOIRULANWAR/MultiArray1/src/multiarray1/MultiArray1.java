/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package multiarray1;

import java.util.Scanner;

public class MultiArray1
{
    public static void main(String[] args)
    {
        Scanner masuk=new Scanner (System.in);
        
        String siswa[][] = new String[5][5];

        for(int i= 0; i<5; i++)
        {
            System.out.println("");
            System.out.println("Data Siswa ke : "+(i+1));

            for(int j=0;j<2;j++)
            {      
                if (j == 0)
                    System.out.print("Nama : ");
                else
                    System.out.print("Nilai : ");
                
                System.out.print("");
                siswa[i][j] = masuk.next();
            }
        }

        System.out.println("Data Siswa yang dimasukan");
        System.out.println("-----------------------------");
        System.out.println("NAMA & NILAI");
        
        for(int i=0;i<5;i++)
        {
            for(int j=0;j<2;j++)
            {
                System.out.print(siswa[i][j]+"   ");
            }
            System.out.println();
        }
    }
}