import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Siswa
 */
public class PersegiPanjang {
    public void luas_persegi(){
		Scanner scaner = new Scanner(System.in);
		System.out.println("============================");
		System.out.println("Menghitung luas persegi");
		System.out.println("============================");
		System.out.print("Masukkan sisi persegi : ");

		int sisi;
		sisi = scaner.nextInt();
		int luas = sisi*sisi;
		
		System.out.println("Sisi persegi = "+ sisi +" cm");
		System.out.println("============================");
		System.out.println("Luas persegi = "+ luas + " cm");
		System.out.println("============================");
	}
}