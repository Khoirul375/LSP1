<?php
include "config.php";
$ambilkategori = mysqli_query($mysqli,'SELECT * FROM tbl_kategori');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script
src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script
src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script
src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="assets/costom.css">
</head>
<body>
    <div class="row">
        <div class="col-sm-12 bg-primary text-center">
            <h2 class="text-light">Kelola Data Barang</h2>
</div>
</div>
<br><br>
<div class="container">
<div class="row">
<div class="col-sm-6 offset-sm-3">
<h5 class="font-weight-bold">Input Data Barang</h5>
<br>
<form action="" method="post" enctype="multipart/form-data">
<div class="form-group row">
<label class="col-sm-3 col-form-label">Kode</label>
<div class="col-sm-8">
<input type="text" class="form-control rounded-pill" name="kode">
</div>
</div>
<div class="form-group row">
<label class="col-sm-3 col-form-label">Nama</label>
<div class="col-sm-9">
<input type="text" class="form-control rounded-pill" name="nama">
</div>
</div>
<div class="form-group row">
<label class="col-sm-3 col-form-label">Deskripsi</label>
<div class="col-sm-9">
<textarea type="text" class="form-control" name="desk" id=
"deskripsi"></textarea>
</div>
</div>
<div class="form-group row">
<label class="col-sm-3 col-form-label">Stok</label>
<div class="col-sm-6">
 <input type="text" class="form-control rounded-pill" name="stok">
</div>
</div>
<div class="form-group row">
<label class="col-sm-3 col-form-label">Harga</label>
<div class="col-sm-7">
<input type="text" class="form-control rounded-pill" name=
"harga">
</div>
</div>
<div class="form-group row">
<label class="col-sm-3 col-form-label">Berat</label>
<div class="col-sm-5">
<input type="text" class="form-control rounded-pill" name=
"berat">
</div>
<div class="col-sm-1">
<p class="mt-2 ml-1 font-italic">gram</p>
</div>
</div>
<div class="form-group row">
<label class="col-sm-3 col-form-label">Gambar</label>
<div class="col-sm-7">
<input type="file" class="form-control rounded-pill" name=
"gambar" accept="image/">
</div>
</div>

<label>Kategori</label>
<select class="form-select" aria-label="Defauld select example" name="kategori" id="kategori">
  <?php while($datakategori = mysqli_fetch_assoc($ambilkategori)) {?>
    <option value="<?php echo $datakategori['id_kategori'];?>">
      <?php echo $datakategori['nama_kategori'];?></option>
      <?php } ?>
  </select>
  

<div class="col-sm-3 offset-sm-4">
<button type="submit" class="btn btn-success" name="submit"> Tambah
 </button>
</div>
</form>
</div>
</div>
</body>
</html>
<?php
include 'config.php';
if (isset($_POST['submit'])) {
$kode = $_POST['kode'];
$nama = $_POST['nama'];
$desk = $_POST['desk'];
$stok = $_POST['stok'];
$harga = $_POST['harga'];
$berat = $_POST['berat'];
$Id = $_POST['kategori'];
$gambar = $_FILES['gambar']['name'];
$tmp_file = $_FILES['gambar']['tmp_name'];
$path = "images/".$gambar;  

if(move_uploaded_file($tmp_file, $path)){
   
    $query = "INSERT INTO tbl_barang(kd_barang, nama, deskripsi, stok,
    harga, berat,gambar,id_kategori) VALUES('".$kode."','".$nama."','".$desk."','".$stok."','".$harga."','".$berat."','".$gambar."','".$Id."')";
    // Eksekusi/ Jalankan query dari variabel $query
    $sql = mysqli_query($mysqli, $query);

      // Cek jika proses simpan ke database sukses atau tidak
    if($sql){
      // Jika Sukses, Lakukan :
      header("location: index.php"); // Redirectke halaman index.php
    }else{
      // Jika Gagal, Lakukan :
      echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
      echo "<br><a href='index.php'>Kembali Ke Form</a>";
    }

 }
}

?>