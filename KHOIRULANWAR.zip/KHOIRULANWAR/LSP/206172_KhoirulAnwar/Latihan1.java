public class Latihan1 {
    public static void main(String[] args) {        
        // BIO DATA SISWA
        // Nama     :   (String)
        // NIS      :   (int) 
        // Kelas    :   (String)
        // Jurusan  :   (String)
        // JenKel   :   (char/String)
        // Alamat   :   (String)
        
        // =======================
        // BIODATA SISWA
        // =======================
        String nama="Khoirul Anwar";
        int nis=206172;
        String kelas="XI RPL 2";
        String ttl="Batang, 29 Mei 2004";
        char jenkel='L';
        String alamat="Ds.Cempereng";
        
        // output
        System.out.println("=============");
        System.out.println("BIODATA SISWA");
        System.out.println("=============");
        
        System.out.println("Nama = "+nama);
        System.out.println("NIS = "+nis);
        System.out.println("Kelas = "+kelas);
        System.out.println("Jurusan = "+ttl);
        System.out.println("Jenis Kelamin = "+jenkel);
        System.out.println("Alamat = "+alamat);
    }
    
}