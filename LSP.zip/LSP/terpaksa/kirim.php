<?php 
include "koneksi.php";

$nama = $_POST['nama'];
$kode = $_POST['kode'];

$namaFile = $_FILES['gambar']['name'];
$tmpFile = $_FILES['gambar']['tmp_name'];
$ekstensiFile = explode('.', $namaFile);
$ekstensiFile = strtolower(end($ekstensiFile));

$gambar = uniqid(). "." . $ekstensiFile;
move_uploaded_file($tmpFile, 'gambar/' . $gambar);

if(isset($_POST['submit'])) {
    $dataku = mysqli_query($koneksi, "INSERT INTO tbl_latihan VALUES ('', '$kode', '$nama', '$gambar')");
    header("Location: tampil.php");


}

?>