/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package multiarray;

/**
 *
 * @author LAB
 */
public class MultiArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int arr[][]={
            {1,2,3},
            {2,4,5},
            {4,4,5}
        };
        
        for (int i=0;
                i<3;
                i++)
        {
            for(int j=0;
                    j<3;
                    j++)
                System.out.print(arr[i][j]+" ");
            System.out.println();
        }
    }    
}