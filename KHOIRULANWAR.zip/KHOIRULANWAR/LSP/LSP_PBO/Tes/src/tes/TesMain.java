/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tes;

/**
 *
 * @author Siswa
 */

import java.util.Scanner;
public class TesMain{
	public static void main (String args[]){
		Scanner scaner = new Scanner(System.in);
		boolean running =true;
		String jawab;
		TesMain luas = new TesMain();
		luas.hitungBangun();

		while(running) {
            System.out.println("Apakah anda ingin keluar?");
            System.out.print("Jawab [ya/tidak]> ");

            jawab = scaner.nextLine();

            // cek jawabnnya, kalau ya maka berhenti mengulang
            if( jawab.equalsIgnoreCase("ya") ){
                running = false;
            }
            else if(jawab.equalsIgnoreCase("tidak")){
             	luas.hitungBangun();
            }
            else{
            	System.out.println("Error");
            }
        }

	}
	public void hitungBangun(){
		Scanner scaner = new Scanner(System.in);
		System.out.println("============================");
		System.out.println("Menghitung bangun datar");
		System.out.println("============================");
		System.out.println("1.persegi");
		System.out.println("2.persegi panjang");
		System.out.print("Masukkan pilihan anda :");	
		int pilihan = scaner.nextInt();	
		switch(pilihan){
			case 1:
				System.out.println("anda memilih persegi");
				luas_persegi();
				break;
			case 2:
				System.out.println("anda memilih persegi panjang");
				luas_persegipanjang();
				break;
			default :
				System.out.println("anda tidak memilih satupun");
		}
	}
	public void luas_persegi(){
		Scanner scaner = new Scanner(System.in);
		System.out.println("============================");
		System.out.println("Menghitung luas persegi");
		System.out.println("============================");
		System.out.print("Masukkan sisi persegi : ");

		int sisi;
		sisi = scaner.nextInt();
		int luas = sisi*sisi;
		
		System.out.println("Sisi persegi = "+ sisi +" cm");
		System.out.println("============================");
		System.out.println("Luas persegi = "+ luas + " cm");
		System.out.println("============================");
	}                                                
	public void luas_persegipanjang(){
		Scanner scaner = new Scanner(System.in);
		int panjang, lebar;
		int luas;
		System.out.println("============================");
		System.out.println("Menghitung luas persegi panjang");
		System.out.println("============================");
		
		System.out.print("Masukkan panjang : ");
		panjang = scaner.nextInt();
		
		System.out.print("Masukkan lebar : ");
		lebar = scaner.nextInt();
		luas = panjang * lebar;

		System.out.println("panjang = "+ panjang +" cm");
		System.out.println("lebar = "+ lebar +" cm");
		System.out.println("============================");
		System.out.println("Luas persegi panjang= "+ luas + " cm");
		System.out.println("============================");
	}
}