/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package strkali;

/**
 *
 * @author LAB
 */
public class StrKali {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String namaVar="Bagaimana Sayayayaya";
        String var1="AAA";
        String var2="BBBB";
        String var3="CCCCC";
        String varSpasi=" ";
        
        System.out.println("Jumlah Char : " + namaVar.length());
        
        System.out.println("Jumlah Char : " + var1.length());
        System.out.println("Menghasilkan Karakter kapital :" +var1.toUpperCase());
        System.out.println("Menghasilkan Karakter kecil :" +var1.toLowerCase());
        System.out.println("____________");
        
        System.out.println("Jumlah Char : " + var2.length());
        System.out.println("Menghasilkan Karakter kapital :" +var2.toUpperCase());
        System.out.println("Menghasilkan Karakter kecil :" +var2.toLowerCase());
        
        System.out.println("____________");
        System.out.println("Jumlah Char : " + var3.length());
        System.out.println("Menghasilkan Karakter kapital :" +var3.toUpperCase());
        System.out.println("Menghasilkan Karakter kecil :" +var3.toLowerCase());
        System.out.println("____________");
        System.out.println(var1 +varSpasi + var2 +varSpasi + namaVar);
//        String teks="Bagaimana jadi pelajar yang baik";
//        System.out.println("Jumlah teksnya : "+teks.length());
//        System.out.println("____________");
//        
//        String awal="Prima";
//        String tengah=" Nurul";
//        String akhir=" Agini";
//        System.out.println(awal + tengah + akhir);
//        System.out.println("_____________");
//        
//        String nama="Saya mulai belajar java";
//        int tahun=2021;
//        
//        String tampil=String.format("Nama saya Prima, %s dari 0, pada tahun %d", nama, tahun);
//        System.out.println(tampil);
//        System.out.println("____________");
//        
//        String var1=("Hallo teman teman saya belajar java");
//        
//        System.out.println("Menghasilkan huruf kapital :" +var1.toUpperCase());
//        System.out.println("_____________");
//        System.out.println("Menghasilkan huruf kecil semua :" +var1.toLowerCase());
//        System.out.println("_____________");
//        
//        String var2=("Halo Teman Teman");
//        
//        System.out.println(var2.charAt(0));
//        System.out.println(var2.charAt(1));
//        System.out.println(var2.charAt(2));
//        System.out.println(var2.charAt(3));
//        System.out.println(var2.charAt(4));
//        System.out.println(var2.charAt(5));
//        System.out.println(var2.charAt(6));
//        System.out.println(var2.charAt(7));
//        System.out.println(var2.charAt(8));
//        System.out.println(var2.charAt(9));
//        System.out.println(var2.charAt(10));
    }
    
}
