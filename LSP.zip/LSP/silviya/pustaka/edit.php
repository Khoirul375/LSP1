<?php
include "koneksi.php";
$id = $_GET['id_buku'];

$tampildata = mysqli_query($hubungkan,"SELECT * FROM tbl_buku WHERE id_buku=$id");
while ($data = mysqli_fetch_assoc($tampildata))
{
    
}
?>