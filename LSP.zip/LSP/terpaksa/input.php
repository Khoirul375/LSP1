<?php 

include "koneksi.php";


?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Barang</title>
</head>
<body>
    <h1>Input Barang</h1>
    <form action="kirim.php" method="post" enctype="multipart/form-data">
        <div> 
            <label for="kode">kode</label>
            <input type="text" name="kode" id="kode">
        </div>
        <div> 
            <label for="nama">nama</label>
            <input type="text" name="nama" id="nama">
        </div>
        <div> 
            <label for="gambar">gambar</label>
            <input type="file" name="gambar" id="gambar">
        </div>
        <div> 
            <button type="submit" name="submit">kirim barang</button>
        </div>
    </form>    
  </body>
</html>